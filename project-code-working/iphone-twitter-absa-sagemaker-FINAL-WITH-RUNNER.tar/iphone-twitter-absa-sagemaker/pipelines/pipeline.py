import sagemaker
from sagemaker.workflow.pipeline import Pipeline
from sagemaker.workflow.steps import TrainingStep
from sagemaker.huggingface import HuggingFace

sess = sagemaker.Session()
role = sagemaker.get_execution_role()

BUCKET = "absa-iphone-twitter-<suffix>"

iphone_estimator = HuggingFace(
    entry_point="train_iphone.py",
    source_dir="../training",
    role=role,
    instance_type="ml.p3.2xlarge",
    transformers_version="4.26",
    pytorch_version="1.13",
    py_version="py39"
)

iphone_train = TrainingStep(
    name="TrainIphoneModel",
    estimator=iphone_estimator,
    inputs={"train": f"s3://{BUCKET}/absa/iphone/train"}
)

pipeline = Pipeline(
    name="ABSA-Iphone-Pipeline",
    steps=[iphone_train],
    sagemaker_session=sess
)

if __name__ == "__main__":
    pipeline.upsert(role_arn=role)
    pipeline.start()
