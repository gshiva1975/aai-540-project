import shap
from transformers import pipeline

model = pipeline("sentiment-analysis")

def explain(text):
    explainer = shap.Explainer(model)
    return explainer([text])
