import pandas as pd
from sklearn.model_selection import train_test_split

df = pd.read_csv("iphone.csv")
df = df[["reviewText", "overall"]]
df["label"] = df["overall"].apply(lambda x: 1 if x >= 4 else 0)
df.rename(columns={"reviewText": "text"}, inplace=True)

train, val = train_test_split(df, test_size=0.2, random_state=42)
train.to_csv("train.csv", index=False)
val.to_csv("validation.csv", index=False)
