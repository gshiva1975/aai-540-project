import pandas as pd
df = pd.read_csv("twitter.csv")
df.to_csv("train.csv", index=False)
