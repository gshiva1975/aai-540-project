#!/bin/bash
set -e

echo "=============================="
echo "ABSA SAGEMAKER FULL PIPELINE"
echo "=============================="

echo "[0] Checking environment..."
python --version
aws --version

echo "[1] Installing dependencies..."
pip install -r requirements.txt

echo "[2] Preprocessing iPhone dataset..."
python preprocessing/preprocess_iphone.py

echo "[2] Preprocessing Twitter dataset..."
python preprocessing/preprocess_twitter.py

echo "Upload generated train/validation CSVs to S3 before continuing."

echo "[3] Running SageMaker Pipeline..."
python pipelines/pipeline.py

echo "Pipeline submitted. Approve model in SageMaker Model Registry."

read -p "Have you approved the model in Model Registry? (y/n): " confirm
if [ "$confirm" != "y" ]; then
  echo "Please approve the model before deploying."
  exit 1
fi

echo "[4] Deploying SageMaker endpoint..."
python deploy/deploy_endpoint.py

echo "[5] Running LangGraph agent..."
python agent/langgraph_agent.py

echo "[6] Logging sample prediction to Feature Store..."
python - <<EOF
from feature_store.log_inference import log_prediction
log_prediction(
    text="Battery drains fast and charger missing",
    sentiment="NEGATIVE",
    confidence=0.94
)
EOF

echo "[7] Running SHAP explanation..."
python shap/explain.py

echo "=============================="
echo "PIPELINE EXECUTION COMPLETE"
echo "=============================="
