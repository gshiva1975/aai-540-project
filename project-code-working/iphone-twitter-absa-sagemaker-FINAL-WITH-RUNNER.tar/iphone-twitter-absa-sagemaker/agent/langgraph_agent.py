import json, boto3
from langgraph.graph import StateGraph, START, END
from typing import TypedDict

runtime = boto3.client("sagemaker-runtime")

ENDPOINTS = {
    "iphone": "iphone-sentiment-endpoint",
    "twitter": "twitter-sentiment-endpoint"
}

class State(TypedDict):
    text: str
    source: str
    sentiment: str
    confidence: float

def infer(state: State):
    resp = runtime.invoke_endpoint(
        EndpointName=ENDPOINTS[state["source"]],
        ContentType="application/json",
        Body=json.dumps({"inputs": state["text"]})
    )
    result = json.loads(resp["Body"].read().decode())[0]
    return {"sentiment": result["label"], "confidence": result["score"]}

g = StateGraph(State)
g.add_node("infer", infer)
g.add_edge(START, "infer")
g.add_edge("infer", END)
app = g.compile()
