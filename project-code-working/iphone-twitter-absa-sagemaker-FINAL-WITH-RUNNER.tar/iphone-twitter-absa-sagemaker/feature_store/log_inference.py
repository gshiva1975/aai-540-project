from sagemaker.feature_store.feature_group import FeatureGroup
import sagemaker, pandas as pd

sess = sagemaker.Session()
fg = FeatureGroup(name="absa-inference-fg", sagemaker_session=sess)

def log_prediction(text, sentiment, confidence):
    fg.put_record({
        "record_id": str(hash(text)),
        "event_time": pd.Timestamp.utcnow().isoformat(),
        "text": text,
        "sentiment": sentiment,
        "confidence": confidence
    })
