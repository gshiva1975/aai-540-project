from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments
from datasets import load_dataset

MODEL = "cardiffnlp/twitter-roberta-base-sentiment"
dataset = load_dataset("csv", data_files={"train": "/opt/ml/input/data/train/train.csv"})

tokenizer = AutoTokenizer.from_pretrained(MODEL)

def tokenize(batch):
    return tokenizer(batch["text"], truncation=True, padding="max_length", max_length=128)

dataset = dataset.map(tokenize, batched=True)
dataset = dataset.rename_column("label", "labels")
dataset.set_format("torch")

model = AutoModelForSequenceClassification.from_pretrained(MODEL, num_labels=3)

args = TrainingArguments(output_dir="/opt/ml/model", num_train_epochs=3)
trainer = Trainer(model=model, args=args, train_dataset=dataset["train"])
trainer.train()
model.save_pretrained("/opt/ml/model")
