from transformers import Trainer, TrainingArguments
from transformers import DistilBertTokenizer, DistilBertForSequenceClassification
from datasets import load_dataset

dataset = load_dataset("csv", data_files={"train": "/opt/ml/input/data/train/train.csv"})
tokenizer = DistilBertTokenizer.from_pretrained("distilbert-base-uncased")

def tokenize(batch):
    return tokenizer(batch["text"], truncation=True, padding="max_length")

dataset = dataset.map(tokenize, batched=True)
dataset = dataset.rename_column("label", "labels")
dataset.set_format("torch")

model = DistilBertForSequenceClassification.from_pretrained("distilbert-base-uncased", num_labels=2)

args = TrainingArguments(output_dir="/opt/ml/model", num_train_epochs=3)
trainer = Trainer(model=model, args=args, train_dataset=dataset["train"])
trainer.train()
model.save_pretrained("/opt/ml/model")
