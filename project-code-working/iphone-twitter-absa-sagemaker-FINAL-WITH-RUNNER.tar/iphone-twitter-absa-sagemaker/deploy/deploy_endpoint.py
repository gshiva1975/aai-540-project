import boto3, sagemaker
from sagemaker.huggingface import HuggingFaceModel

MODEL_PACKAGE_GROUP = "IphoneSentimentGroup"
ENDPOINT_NAME = "iphone-sentiment-endpoint"

sm = boto3.client("sagemaker")
sess = sagemaker.Session()
role = sagemaker.get_execution_role()

pkgs = sm.list_model_packages(
    ModelPackageGroupName=MODEL_PACKAGE_GROUP,
    ModelApprovalStatus="Approved",
    SortBy="CreationTime",
    SortOrder="Descending"
)

pkg_arn = pkgs["ModelPackageSummaryList"][0]["ModelPackageArn"]
details = sm.describe_model_package(ModelPackageName=pkg_arn)
container = details["InferenceSpecification"]["Containers"][0]

model = HuggingFaceModel(
    model_data=container["ModelDataUrl"],
    role=role,
    transformers_version="4.26",
    pytorch_version="1.13",
    py_version="py39"
)

model.deploy(
    endpoint_name=ENDPOINT_NAME,
    instance_type="ml.m5.xlarge",
    initial_instance_count=1
)

print("Endpoint deployed:", ENDPOINT_NAME)
